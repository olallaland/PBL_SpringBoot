// point对象
function Point(x, y, color) {
    this.x = x;
    this.y = y;
    this.color = color;

    // converse the given coordinates to webgl coordinates
    this.newX = function() {
        return (this.x - canvasSize.maxX / 2) / (canvasSize.maxX / 2);
    };
    this.newY = function() {
        return (canvasSize.maxY / 2 - this.y) / (canvasSize.maxY / 2);
    };
}
